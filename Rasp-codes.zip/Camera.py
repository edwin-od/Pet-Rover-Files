#Pins to the PIC:
#Face detected
#Object detected      }
#Forward (Dimensions) }Can be used in one analog pin (+5 Fwd -5 Object detected)
#Left   }
#Right  }Can be used in one analog pin (+5 Right -5 Left)


import picamera
import picamera.array

#PUBLIC VARIABLES

#[(0->255),(0->255),(0->255)]
detect = [40,25,255]
#[(0->1),(0->1),(0->1)]
colorDetectionError = [1,1,0.3]
#Cannot be float and cannot be less than 1
pixelScanDivider = 2                                

#PRIVATE VARIABLES

u = [-1,-1]                                         #[x,y] <-- upper pixel
d = [-1,-1]                                         #[x,y] <-- down pixel
r = [-1,-1]                                         #[x,y] <-- right pixel
l = [-1,-1]                                         #[x,y] <-- left pixel

lowerBoundDetect = [detect[0]-(255*colorDetectionError[0]),colorDetectionError[1]-(255*colorDetectionError[1]),detect[2]-(255*colorDetectionError[2])]
upperBoundDetect = [detect[0]+(255*colorDetectionError[0]),detect[1]+(255*colorDetectionError[1]),detect[2]+(255*colorDetectionError[2])]

if lowerBoundDetect[0] > 255:
    lowerBoundDetect[0] = 255
elif lowerBoundDetect[0] < 0:
    lowerBoundDetect[0] = 0
if lowerBoundDetect[1] > 255:
    lowerBoundDetect[1] = 255
elif lowerBoundDetect[1] < 0:
    lowerBoundDetect[1] = 0
if lowerBoundDetect[2] > 255:
    lowerBoundDetect[2] = 255
elif lowerBoundDetect[2] < 0:
    lowerBoundDetect[2] = 0

if upperBoundDetect[0] > 255:
    upperBoundDetect[0] = 255
elif upperBoundDetect[0] < 0:
    upperBoundDetect[0] = 0
if upperBoundDetect[1] > 255:
    upperBoundDetect[1] = 255
elif upperBoundDetect[1] < 0:
    upperBoundDetect[1] = 0
if upperBoundDetect[2] > 255:
    upperBoundDetect[2] = 255
elif upperBoundDetect[2] < 0:
    upperBoundDetect[2] = 0
    
#print(str(lowerBoundDetect)+' <= '+str(detect)+' <= '+str(upperBoundDetect))       #Color detection range

with picamera.PiCamera() as cam:
    #cam.resolution = (1376, 768)                   #Actual resolution
    cam.resolution = (128, 112)
    with picamera.array.PiRGBArray(cam) as out:
        cam.start_preview(fullscreen = False, window = (700,20,352,192))
        detected = False
        while not detected:
            cam.capture(out, format = 'rgb')
            k = 0
            y = 0
            while pixelScanDivider * k < out.array.shape[0]:
                y = pixelScanDivider * k
                j = 0
                x = 0
                while pixelScanDivider * j < out.array.shape[1]:
                    x = pixelScanDivider * j
                    i = out.array[y][x]
                    if lowerBoundDetect[0] <= i[0] <= upperBoundDetect[0] and lowerBoundDetect[1] <= i[1] <= upperBoundDetect[1] and lowerBoundDetect[2] <= i[2] <= upperBoundDetect[2]:
                        if u == [-1,-1]:
                            u = [x,y]
                    x1 = out.array.shape[1]-x-1
                    y1 = out.array.shape[0]-y-1
                    i = out.array[y1][x1]
                    if lowerBoundDetect[0] <= i[0] <= upperBoundDetect[0] and lowerBoundDetect[1] <= i[1] <= upperBoundDetect[1] and lowerBoundDetect[2] <= i[2] <= upperBoundDetect[2]:
                        if d == [-1,-1]:
                            d = [x1,y1]
                    
                    x1 = int(round(out.array.shape[1]-(y * ((out.array.shape[1]-1) / (out.array.shape[0]-1)))-1))
                    y1 = int(round(x * ((out.array.shape[0]-1) / (out.array.shape[1]-1))))
                    i = out.array[y1][x1]
                    if lowerBoundDetect[0] <= i[0] <= upperBoundDetect[0] and lowerBoundDetect[1] <= i[1] <= upperBoundDetect[1] and lowerBoundDetect[2] <= i[2] <= upperBoundDetect[2]:
                        if r == [-1,-1]:
                            r = [x1,y1]
                    
                    x1 = int(round(y * ((out.array.shape[1]-1) / (out.array.shape[0]-1))))
                    y1 = int(round(x * ((out.array.shape[0]-1) / (out.array.shape[1]-1))))
                    i = out.array[y1][x1]
                    if lowerBoundDetect[0] <= i[0] <= upperBoundDetect[0] and lowerBoundDetect[1] <= i[1] <= upperBoundDetect[1] and lowerBoundDetect[2] <= i[2] <= upperBoundDetect[2]:
                        if l == [-1,-1]:
                            l = [x1,y1]
                    j = j + 1
                k = k + 1
                
            #if u != [-1,-1] and d != [-1,-1] and r != [-1,-1] and l != [-1,-1]:
            #    xc = int(round((l[0]+r[0])/2))
            #    yc = int(round((d[0]+u[0])/2))
            #    print('Detected: Center => ['+str(xc)+', '+str(yc)+']')
            #    detected = False
                
                #for x in range(l[0],r[0]+1):
                #    for y in range(u[1],d[1]+1):
                #        out.array[y][x][0] = 0
                #        out.array[y][x][1] = 0
                #        out.array[y][x][2] = 0
                
            #else:
            #    print('Not detected')
            print
            u = [-1,-1]
            d = [-1,-1]
            r = [-1,-1]
            l = [-1,-1]
            out.truncate(0)
